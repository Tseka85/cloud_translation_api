<?php
// Heading
$_['heading_title'] = 'Cloud Translation API';

// Text
$_['text_extension'] = 'Extension';
$_['text_success'] = 'Module settings successfully saved!';
$_['text_edit'] = 'Settings of the Translation Module';

// Entry
$_['entry_status'] = 'Status';
$_['entry_api_key'] = 'Translator API key';

// Error
$_['error_permission'] = 'You do not have permission to edit this module!';
$_['error_api_key'] = 'API key must be specified!';
